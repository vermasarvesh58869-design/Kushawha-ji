const words = ["websites", "digital projects", "creative ideas", "web experiences"];
let i = 0, j = 0, deleting = false;
const typing = document.getElementById("typing");

function type(){
  const word = words[i];
  typing.textContent = word.slice(0, j);
  if(!deleting && j < word.length){ j++; setTimeout(type, 90); }
  else if(!deleting){ deleting = true; setTimeout(type, 1200); }
  else if(j > 0){ j--; setTimeout(type, 45); }
  else { deleting = false; i = (i + 1) % words.length; setTimeout(type, 250); }
}
type();
document.getElementById("year").textContent = new Date().getFullYear();
